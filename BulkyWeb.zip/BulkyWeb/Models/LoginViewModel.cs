﻿using System.ComponentModel.DataAnnotations;

namespace BulkyWeb.Models
{
    public class LoginViewModel
    {
        [Required(AllowEmptyStrings = false)]
        [EmailAddress]
        public string? Email { get; set; }

        [Required(AllowEmptyStrings = false)]
        [DataType(DataType.Password)]
        public string? Password { get; set; }
    }
}
