﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace BulkyWeb.Models
{
    public class Student
    {
        public int StudentId { get; set; }
        public string? StudentName { get; set;}
        public int ClassKeyId { get; set; }
        public ClassKey? ClassKey { get; set; }
    }
}
