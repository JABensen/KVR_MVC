﻿using System.ComponentModel.DataAnnotations;
namespace BulkyWeb.Models
{
    public class StudentDTO
    {
        public string? StudentName { get; set; }
        public string? Key { get; set; }
    }
}
