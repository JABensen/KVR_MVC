﻿using System.ComponentModel.DataAnnotations;
namespace BulkyWeb.Models
{
    public class ClassKey
    {
        public int ClassKeyId { get; set; }
        public string? Key {  get; set; }
        public int ProfessorId { get; set; }
        public Professor? Professor { get; set; }
        public ICollection<Student>? Students { get; set; }
    }
}
