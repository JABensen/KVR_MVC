﻿using System.ComponentModel.DataAnnotations;

namespace BulkyWeb.Models
{
    public class Professor
    {
        public int ProfessorId { get; set; }
        public string? ProfessorUsername { get; set; }
        public string? ProfessorEmail { get; set; }
        public string? HashedPassword { get; set; }
        public ICollection<ClassKey>? ClassKeys { get; set; }
    }
}
