﻿using Microsoft.EntityFrameworkCore;
using BulkyWeb.Models;

namespace BulkyWeb.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }

        //public DbSet<AssociatedTaskIndex> AssociatedTasks { get; set; }
        //public DbSet<EventLog> EventLogs { get; set; }
        //public DbSet<Lab> Labs { get; set; }
        //public DbSet<ObjectMetric> ObjectMetrics { get; set; }
        //public DbSet<Professor> Professors { get; set; }
        //public DbSet<Student> Students { get; set; }

        public DbSet<Professor> Professors { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<ClassKey> ClassKeys { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Student>()
                .HasOne(s => s.ClassKey)
                .WithMany(ck => ck.Students)
                .HasForeignKey(s => s.ClassKeyId);

            modelBuilder.Entity<ClassKey>()
                .HasOne(ck => ck.Professor)
                .WithMany(p => p.ClassKeys)
                .HasForeignKey(ck => ck.ProfessorId);
        }
    }
}
