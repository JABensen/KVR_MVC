﻿using Microsoft.AspNetCore.Mvc;

namespace BulkyWeb.Controllers
{
    public class MetricsController : Controller
    {
        public IActionResult Metrics()
        {
            return View();
        }
    }
}
