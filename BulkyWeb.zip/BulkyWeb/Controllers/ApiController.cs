﻿using Microsoft.AspNetCore.Mvc;
using BulkyWeb.Models;
using Newtonsoft.Json;
public class ApiController : Controller
{
    [HttpPost]
    [Route("api/data")] // Customize the route as needed
    public IActionResult ReceiveData([FromBody] StudentDTO studentDTO)
    {
        // Check if the model is valid
        if (!ModelState.IsValid)
        {
            // If the model is not valid, return a bad request with validation errors
            return BadRequest(ModelState);
        }

        try
        {
            string json = JsonConvert.SerializeObject(studentDTO);
            return Ok("Hello, this is your server speaking.  I'd like to return your json string:\n" + json);
        }
        catch (Exception ex)
        {
            // If an exception occurs during serialization, return a server error
            return StatusCode(500, $"An error occurred: {ex.Message}");
        }
    }
}